import Heading from '@/components/Shared/Heading'
import React from 'react'

const StorePage = () => {
    return (
        <div>
            <Heading
                headingText='STORE'
                subHeadingText='Coming Soon'
            />
        </div>
    )
}

export default StorePage
